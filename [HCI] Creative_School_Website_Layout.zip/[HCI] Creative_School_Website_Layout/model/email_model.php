<?php
require_once('dbconfig.php');
require_once('./PHPMailer-5.2-stable/PHPMailerAutoload.php');
class Email
{
    public $host;
    public $port;
    public $username;
    public $password;
    public $subject;
    public $body;
    public $recepient;

    public static function insert_config($objConfig)
    {
        $db=DbConnection::getInstance();
        $conn = $db->getConnection();
        //Delete old email configuration from database
        $sql1 = oci_parse($conn, "DELETE FROM EMAIL_CONFIG WHERE ID=1");
        oci_execute($sql1, OCI_DEFAULT);
        oci_commit($conn);
        //Insert new email configuration in database
        $sql = 'INSERT INTO EMAIL_CONFIG(HOST,PORT,USERNAME,PASSWORD, ID) '.
        'VALUES(:host, :port, :username, :password, :id)';
        $compiled = oci_parse($conn, $sql);
        $id = 1;
        oci_bind_by_name($compiled, ':host', $objConfig->host);
        oci_bind_by_name($compiled, ':port', $objConfig->port);
        oci_bind_by_name($compiled, ':username', $objConfig->username);
        oci_bind_by_name($compiled, ':password', $objConfig->password);
        oci_bind_by_name($compiled, ':id', $id);
        oci_execute($compiled);
    }

    public static function send_email($objEmail)
    {
        //Save composed email in database
        $status = 1;
        $db=DbConnection::getInstance();
        $conn = $db->getConnection();
        $sql = 'INSERT INTO SAVED_EMAILS(SUBJECT,BODY,RECEPIENT, STATUS) '.
        'VALUES(:SUBJECT, :BODY, :RECEPIENT, :STATUS)';
        $compiled = oci_parse($conn, $sql);
        oci_bind_by_name($compiled, ':SUBJECT', $objEmail->subject);
        oci_bind_by_name($compiled, ':BODY', $objEmail->body);
        oci_bind_by_name($compiled, ':RECEPIENT', $objEmail->recepient);
        //Verify appropriate time
        date_default_timezone_set('Africa/Cairo');
        $apm = date('a');
        $current_hour = date('h');
        if($current_hour > 01 && $current_hour < 07 && $apm = 'am'){//Check if time is between 1 AM and 7 AM
            echo "Night time detected. Notification will be saved and sent in the morning :)";
            $status = 0;
            oci_bind_by_name($compiled, ':STATUS', $status);
            oci_execute($compiled);
        }
        else{ //Retrieve email config and send email
            $status = 1;
            oci_bind_by_name($compiled, ':STATUS', $status);
            oci_execute($compiled);
            $sql = 'select * from EMAIl_CONFIG';
            $stid = oci_parse($conn, $sql);
            oci_execute($stid);
            $config_data = array();
            $i=0;
            while ($row = oci_fetch_array($stid, OCI_RETURN_NULLS+OCI_ASSOC)){
                foreach ($row as $item) {
                    $config_data[$i] = htmlentities($item, ENT_QUOTES);
                    $i++;
                }
            }
            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'ssl';
            $mail->Host = $config_data[0];
            $mail->Port = $config_data[1];
            $mail->isHTML();
            $mail->Username = $config_data[2];
            $mail->Password = $config_data[3];
            $mail->SetFrom('no-reply@howcode.org');
            $mail->Subject = $objEmail->subject;
            $mail->Body = $objEmail->body;
            $mail->AddAddress($objEmail->recepient);
            $mail->Send();
            echo "Notification sent successfuly!";
        }
    }
}
?>