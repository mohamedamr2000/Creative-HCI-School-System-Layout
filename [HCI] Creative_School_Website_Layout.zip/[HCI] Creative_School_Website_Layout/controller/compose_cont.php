<?php
require_once('./model/email_model.php');
require_once('./compose.php');
if(isset($_POST['btn_send']))
{
    $obj = new Email();
    $obj->subject = $_POST['Subject']; 
    $obj->body = $_POST['Body'];
    $obj->recepient = $_POST['Recipenet'];
    Email::send_email($obj);
}
?>