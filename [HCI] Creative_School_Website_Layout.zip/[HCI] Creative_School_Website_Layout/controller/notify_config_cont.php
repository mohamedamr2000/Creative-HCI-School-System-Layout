<?php
require_once('./model/email_model.php');
require_once('./notify_config.php');
if(isset($_POST['btn_save']))
{
    $obj = new Email();
    $obj->host = $_POST['Host']; 
    $obj->port = $_POST['Port'];
    $obj->username = $_POST['User'];
    $obj->password = $_POST['Mail_Password'];
    Email::insert_config($obj);
}
?>