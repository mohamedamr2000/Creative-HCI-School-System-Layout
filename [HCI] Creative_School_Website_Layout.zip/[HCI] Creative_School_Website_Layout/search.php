<form method="POST">
    <p>Enter PK</p>
<input type="text" name="Search" placeholder="Search" class="form-control mb-2">
<button class="btn btn-dark" name="btn_search"> Search </button>
</form>

<?php
require_once('./model/dbconfig.php');
function search_pk($pk)
{
$db=DbConnection::getInstance();
$conn = $db->getConnection();
$sql = oci_parse($conn, "SELECT PK FROM MDM.MARKET WHERE PK LIKE '%$pk%'");
oci_execute($sql);
$config_data = array();
$i=0;
while ($row = oci_fetch_array($sql, OCI_RETURN_NULLS+OCI_ASSOC)){
    foreach ($row as $item) {
        //$config_data[$i] = htmlentities($item, ENT_QUOTES);
        //$i++;
        $term = htmlentities($item, ENT_QUOTES);
        echo $term; 
    }
}
}
if(isset($_POST['btn_search']))
{
    $pk = $_POST['Search']; 
    search_pk($pk);
}
?>


