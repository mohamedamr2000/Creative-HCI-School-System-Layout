<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
    <link rel ="stylesheet" type="text/css" href="templates/style2.css">
    <link rel="stylesheet" href="templates/bootstrap.css">
    <link rel="stylesheet" href="templates/master.css">
</head>
<body>
    <div class="banner-area">
        <div class="content-area">
           <div class="content">
           <h1>Baby Garden School</h1>

              <p><b>مدرسة بيبي جاردن للغات</b></p>
              <p>Leading the smart education.</p>
              
              <a href="Home.html" class="btn btn-primary">Student Login</a>
              <a href="compose.php" class="btn btn-primary">Staff Portal</a>
           </div>
        </div>
    </div>
</body>
</html>